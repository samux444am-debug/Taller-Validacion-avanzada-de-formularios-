const form = document.getElementById("registro");
const campos = Array.from(form.elements).filter(el => el.tagName === "INPUT");
const resumen = document.getElementById("resumen");
const estado = document.getElementById("estado");
const boton = document.getElementById("enviar");

/* Todos los textos en un solo lugar */
const MENSAJES = {
  usuario: {
    valueMissing: "Escribe un nombre de usuario.",
    tooShort: "El usuario debe tener al menos 4 caracteres.",
    tooLong: "El usuario no puede superar los 16 caracteres.",
    patternMismatch: "Usa solo letras, números y guion bajo (_), sin espacios."
  },
  correo: {
    valueMissing: "Escribe tu correo electrónico.",
    typeMismatch: "Escribe un correo válido, por ejemplo nombre@dominio.com."
  },
  edad: {
    valueMissing: "Escribe tu edad.",
    badInput: "Escribe la edad usando solo números.",
    rangeUnderflow: "Debes tener al menos 18 años para registrarte.",
    rangeOverflow: "La edad máxima permitida es 99 años."
  },
  clave: {
    valueMissing: "Escribe una contraseña.",
    tooShort: "La contraseña debe tener al menos 8 caracteres."
  },
  confirmar: {
    valueMissing: "Repite la contraseña para confirmarla.",
    customError: "Las contraseñas no coinciden."
  }
};

/* Orden de revisión: se muestra solo el primer fallo */
const ORDEN = ["valueMissing", "badInput", "typeMismatch", "tooShort", "tooLong",
               "rangeUnderflow", "rangeOverflow", "patternMismatch", "customError"];

let errorServidor = null; // { campo, valor, mensaje }

/* EVALUAR: decide el mensaje (sin tocar el DOM visible) */
function evaluar(campo) {
  campo.setCustomValidity(""); // limpiar SIEMPRE antes de reevaluar

  if (campo.id === "confirmar" && campo.value && campo.value !== form.elements.clave.value) {
    campo.setCustomValidity(MENSAJES.confirmar.customError);
  }
  if (errorServidor && errorServidor.campo === campo.id && errorServidor.valor === campo.value) {
    campo.setCustomValidity(errorServidor.mensaje);
  }

  if (campo.validity.valid) return "";

  const propiedad = ORDEN.find(p => campo.validity[p]);
  const mensaje = propiedad === "customError"
    ? campo.validationMessage
    : (MENSAJES[campo.id] && MENSAJES[campo.id][propiedad]) || campo.validationMessage; // respaldo
  campo.setCustomValidity(mensaje);
  return mensaje;
}

/* MOSTRAR: refleja el estado en clases, ARIA y texto */
function mostrar(campo, mensaje) {
  const invalido = mensaje !== "";
  const zonaError = document.getElementById("error-" + campo.id);
  campo.classList.toggle("es-invalido", invalido);
  campo.classList.toggle("es-valido", !invalido && campo.value !== "");
  campo.setAttribute("aria-invalid", String(invalido));
  zonaError.textContent = mensaje; // textContent: nunca innerHTML
}

function validarCampo(campo) {
  const mensaje = evaluar(campo);
  mostrar(campo, mensaje);
  return mensaje === "";
}

function limpiar(campo) {
  campo.setCustomValidity("");
  campo.classList.remove("es-valido", "es-invalido");
  campo.removeAttribute("aria-invalid");
  document.getElementById("error-" + campo.id).textContent = "";
}

/* Eventos por campo: blur valida; input revalida si ya hay error */
campos.forEach(campo => {
  campo.addEventListener("blur", () => validarCampo(campo));
  campo.addEventListener("input", () => {
    if (campo.classList.contains("es-invalido")) validarCampo(campo);
    if (campo.id === "clave" && form.elements.confirmar.value) validarCampo(form.elements.confirmar);
  });
});

/* Evita la burbuja nativa; invalid solo se escucha en captura (no burbujea) */
form.addEventListener("invalid", e => e.preventDefault(), true);

/* Servidor simulado */
function enviarAlServidor(datos) {
  return new Promise((resolver, rechazar) => {
    setTimeout(() => {
      if (datos.correo.trim().toLowerCase() === "ocupado@ejemplo.com") {
        rechazar({ campo: "correo", mensaje: "Este correo ya está registrado. Usa otro o inicia sesión." });
      } else {
        resolver({ ok: true });
      }
    }, 1200);
  });
}

function textoResumen(n) {
  return n === 1
    ? "Hay 1 campo por corregir. Revisa el mensaje junto al campo."
    : `Hay ${n} campos por corregir. Revisa los mensajes junto a cada campo.`;
}

form.addEventListener("submit", async e => {
  e.preventDefault();
  estado.textContent = "";

  const invalidos = campos.filter(c => !validarCampo(c));
  if (invalidos.length > 0) {
    resumen.textContent = textoResumen(invalidos.length);
    invalidos[0].focus();
    return;
  }
  resumen.textContent = "";
  estado.textContent = "Enviando datos…";
  boton.disabled = true;

  try {
    await enviarAlServidor({ usuario: form.elements.usuario.value, correo: form.elements.correo.value });
    form.reset();
    campos.forEach(limpiar);
    errorServidor = null;
    estado.textContent = "Registro exitoso. ¡Bienvenido!";
  } catch (err) {
    const campo = form.elements[err.campo];
    errorServidor = { campo: err.campo, valor: campo.value, mensaje: err.mensaje };
    validarCampo(campo);
    resumen.textContent = textoResumen(1);
    estado.textContent = "No se pudo completar el registro.";
    campo.focus();
  } finally {
    boton.disabled = false;
  }
});
